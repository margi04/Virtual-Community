﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mission.Entities.Context;
using Mission.Entities.Entities;
using Mission.Entities.Models;
using Mission.Repositories.IRepositories;

namespace Mission.Repositories.Repositories
{
    public class LoginRepositories(MissionDbContext missionDbContext) : ILoginRepositories
    {
        private readonly MissionDbContext _missionDbContext = missionDbContext;
        public LoginUserResponseModel login(LoginUserRequestModel model)
        {
            var existingUser = _missionDbContext.Users.Where(x => x.EmailAddress.ToLower() == model.EmailAddress.ToLower() && !x.IsDeleted).FirstOrDefault();
            if (existingUser == null)
            {
                return new LoginUserResponseModel() { Message = "Email address Not found" };
            }
            if (existingUser.Password != model.Password)
            {
                return new LoginUserResponseModel() { Message = "Incorrect Password" };
            }
            return new LoginUserResponseModel()
            {
                Id = existingUser.Id,
                FirstName = existingUser.FirstName,
                LastName = existingUser.LastName,
                EmailAddress = existingUser.EmailAddress,
                PhoneNumber = existingUser.PhoneNumber,
                UserImage = existingUser.UserImage,
                UserType = existingUser.UserType,
                Message = "Login Successfully"
            };
        }
    
    public bool Register(RegisterUserRequestModel model)
        {
            if (_missionDbContext.Users.Any(x => x.EmailAddress.ToLower() == model.EmailAddress.ToLower()))
            {
                return false; // Email already exists
            }

            var user = new User
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                EmailAddress = model.EmailAddress,
                PhoneNumber = model.PhoneNumber,
                Password = model.Password, // Plain text password
                UserType = model.UserType,
                UserImage = model.UserImage,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
            };

            _missionDbContext.Users.Add(user);
            _missionDbContext.SaveChanges();
            return true;
        }
    }
    }
