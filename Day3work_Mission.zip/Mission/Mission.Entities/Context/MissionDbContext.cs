﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Mission.Entities.Entities;

namespace Mission.Entities.Context
{

    public class MissionDbContext : DbContext

    {
        public MissionDbContext(DbContextOptions<MissionDbContext> options) : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            AppContext.SetSwitch("Npgsql.EnableLegencyTimestampBehavior", true);
            modelBuilder.Entity<User>().HasData(new User()
            {
                Id = 1,
                FirstName = "Margi",
                LastName = "Vagh",
                EmailAddress = "vaghmargi@gmail.com",
                UserType="Admin",
                Password = "margi123",
                PhoneNumber= "1234567890",
                CreatedDate = new DateTime(2019, 1, 1,0,0,0, DateTimeKind.Utc),

            }
                
          );
            base.OnModelCreating(modelBuilder);
        }
        
    }
}
