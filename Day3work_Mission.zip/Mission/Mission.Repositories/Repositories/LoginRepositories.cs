﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mission.Entities.Context;
using Mission.Entities.Entities;
using Mission.Repositories.IRepositories;

namespace Mission.Repositories.Repositories
{
    public class LoginRepositories(MissionDbContext missionDbContext) : ILoginRepositories

    {
        private readonly MissionDbContext _missionDbContext = missionDbContext;
        
        public User Login(string EmailAddress, string Password)
        {
            var user =  _missionDbContext.Users.Where(x => x.EmailAddress == EmailAddress && x.Password == Password).FirstOrDefault();
            if (user == null)
            {
                return null;
            }
            return user;
        }
    }
}
