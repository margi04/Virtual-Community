﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mission.Entities.Entities;
using Mission.Repositories.IRepositories;
using Mission.Repositories.Repositories;
using Mission.Services.IServices;

namespace Mission.Services.Services
{
    public class LoginService: ILoginService
    {
        private readonly ILoginRepositories _LoginRepositories;
        public LoginService(ILoginRepositories LoginRepositories)
        {
            _LoginRepositories = LoginRepositories;
        }
        public User Login(string username, string password)
        {
           
            return this._LoginRepositories.Login(username, password);
        }
    }
}
