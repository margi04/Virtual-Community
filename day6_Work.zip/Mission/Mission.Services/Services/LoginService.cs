﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mission.Entities.Entities;
using Mission.Entities.Models;
using Mission.Repositories.IRepositories;
using Mission.Services.Helper;
using Mission.Services.IServices;

namespace Mission.Services.Services
{
    public class LoginService : ILoginService
    {
        private readonly ILoginRepositories _loginRepository;
        private readonly JwtServices _jwtService;
        public LoginService(ILoginRepositories loginRepository, JwtServices jwtService)
        {
            _loginRepository = loginRepository;
            _jwtService = jwtService;
        }
        public ResponseResult login(LoginUserRequestModel model)
        {
            var userObj = this._loginRepository.login(model);
            ResponseResult result = new ResponseResult();
            if (userObj.Message == "Login Successfully")
            {
                result.Message = userObj.Message;
                result.Result = ResponseStatus.Success;
                result.Data = _jwtService.GetToken(userObj.FirstName, userObj.EmailAddress, userObj.UserType);
            }
            else
            {
                result.Message = userObj.Message;
                result.Result = ResponseStatus.Error;
            }
            return result;
        }
        public string Register(RegisterUserRequestModel model)
        {
            return _loginRepository.Register(model);
        }
        public UserDetails loginUserDetailsById(int id)
        {
            return _loginRepository.LoginUserDetailsById(id);
        }

        public string updateUser(UserDetails model, string webhostpahth)
        {
            return _loginRepository.UpdateUser(model, webhostpahth);
        }
    }
}
