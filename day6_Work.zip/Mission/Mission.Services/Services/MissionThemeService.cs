﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mission.Entities.Entities;
using Mission.Entities.Models;
using Mission.Repositories.IRepositories;
using Mission.Repositories.Repositories;
using Mission.Services.IServices;

namespace Mission.Services.Services
{
    public class MissionThemeService(IMissionThemeRepository missionThemeRepository) : IMissionThemeService
    {
        private readonly IMissionThemeRepository _missionThemeRepository = missionThemeRepository;

        public Task<bool> AddMissionTheme(MissionThemeModel model)
        {
            MissionTheme missionTheme = new MissionTheme()
            {
                id = model.Id,
                status = model.Status,
                Themename = model.ThemeName,
            };
            return _missionThemeRepository.AddMissionTheme(missionTheme);
        }
        public Task<List<MissionThemeModel>> GetAllMissionThemes()
        {
            return _missionThemeRepository.GetAllMissionTheme();
        }
        public Task<MissionThemeModel> GetMissionThemesById(int id)
        {
            return _missionThemeRepository.GetMissionThemeById(id);
        }
        public Task<bool> UpdateMissionTheme(MissionThemeModel model)
        {
            MissionTheme missionTheme = new MissionTheme()
            {
                id = model.Id,
                status = model.Status,
                Themename = model.ThemeName,
            };
            return _missionThemeRepository.UpdateMissionTheme(missionTheme);
        }

        public string MissionThemeDelete(int id)
        {
            return _missionThemeRepository.MissionThemeDelete(id);
        }
    }
}
