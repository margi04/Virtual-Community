﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Mission.Entities.Context;
using Mission.Entities.Entities;
using Mission.Entities.Models;
using Mission.Repositories.IRepositories;

namespace Mission.Repositories.Repositories
{
    public class MissionThemeRepository(MissionDbContext missionDbContext) : IMissionThemeRepository
    {
        private readonly MissionDbContext _missionDbContext = missionDbContext; 

        public async Task<bool> AddMissionTheme(MissionTheme missionTheme)
        {
            bool alreadyExist = await _missionDbContext.missionThemes.AnyAsync(m => m.Themename.ToLower() == missionTheme.Themename.ToLower() && !m.IsDeleted);
            if (alreadyExist)
            {
                return false;
            }

            await _missionDbContext.missionThemes.AddAsync(missionTheme);
            await _missionDbContext.SaveChangesAsync();
            return true;
        }

        public Task<List<MissionThemeModel>> GetAllMissionTheme()
        {
            return _missionDbContext.missionThemes.Where(m => !m.IsDeleted).Select(m => new MissionThemeModel()
            {
                Id = m.id,
                ThemeName = m.Themename,
                Status = m.status,
            }).ToListAsync();
        }

        public Task<MissionThemeModel> GetMissionThemeById(int id)
        {
            return _missionDbContext.missionThemes.Where(m => m.id == id && !m.IsDeleted).Select(m => new MissionThemeModel()
            {
                Id = m.id,
                ThemeName = m.Themename,
                Status = m.status,
            }).FirstOrDefaultAsync();
        }

        public async Task<bool> UpdateMissionTheme(MissionTheme missionTheme)
        {
            var missionthemeExist = await _missionDbContext.missionThemes.FirstOrDefaultAsync(m => m.id == missionTheme.id && !m.IsDeleted);
            if (missionthemeExist == null)
            {
                return false;
            }

            missionthemeExist.Themename = missionTheme.Themename;
            missionthemeExist.status = missionTheme.status;
            missionthemeExist.Modified = DateTime.UtcNow;

            await _missionDbContext.SaveChangesAsync();
            return true;
        }
        public string MissionThemeDelete(int id)
        {
            var theme = _missionDbContext.missionThemes.Where(x => x.id == id).FirstOrDefault();

            if (theme == null) throw new Exception("Theme not exist");

            theme.IsDeleted = true;
            theme.Modified = DateTime.UtcNow;
            _missionDbContext.missionThemes.Update(theme);
            _missionDbContext.SaveChanges();
            return "Theme deleted!";
        }
    }
}
