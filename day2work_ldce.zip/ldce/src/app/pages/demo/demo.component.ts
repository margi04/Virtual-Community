import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DemoService } from '../../services/demo.service';
@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {
name = ' ';

constructor(private demoservice: DemoService) { }
  // You can inject services here if needed
  ngOnInit() {
    this.demoservice.fetchData();
}
}